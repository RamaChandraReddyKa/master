
#ifndef SEC3_AVG_H
#define SEC3_AVG_H

int avg( int x, int y );

#endif

