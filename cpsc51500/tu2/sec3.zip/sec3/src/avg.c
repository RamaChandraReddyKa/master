
#include "avg.h"

int avg( int x, int y )
{
  int sum = x + y;
  return sum / 2;
}

